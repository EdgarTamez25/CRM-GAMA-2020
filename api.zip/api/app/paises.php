<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class paises extends Model
{
    //
}
