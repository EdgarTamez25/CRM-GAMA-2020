<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class det_prod extends Model
{
    //
}
